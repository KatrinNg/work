import axios from 'axios';
import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import { CircularProgress } from '@material-ui/core';

const Axios = axios.create({
  timeout: 20000,
  baseURL:'http://192.168.107.154:8080/'
});

let requestCount = 0;

const showLoading = () => {
  if (requestCount === 0) {
    const dom = document.createElement('div');
    dom.setAttribute('id', 'loading');
    document.body.appendChild(dom);
    ReactDOM.render(<CircularProgress color='primary' />, dom);
  }
  requestCount++;
};

const hideLoading = () => {
  requestCount--;
  if (requestCount === 0) {
    document.body.removeChild(document.getElementById('loading'));
  }
};

const handleErr = (err) => {
  if (err.config.headers.isLoading !== false) {
    hideLoading();
  }
  console.log(err)
  if (err && err.response) {
    switch (err.response.status) {
      case 400:
        err.message = 'Bad Request(400)';
        break;
      case 401:
        err.message = 'Please re-login without authorization(401)';
        break;
      case 403:
        err.message = 'Forbidden(403)';
        break;
      case 404:
        err.message = 'Not Found(404)';
        break;
      case 408:
        err.message = 'Request Timeout(408)';
        break;
      case 500:
        err.message = 'Internal Server Error(500)';
        break;
      case 501:
        err.message = 'Not Implemented(501)';
        break;
      case 502:
        err.message = 'Bad Gateway(502)';
        break;
      case 503:
        err.message = 'Service Unavailable(503)';
        break;
      case 504:
        err.message = 'Gateway Timeout(504)';
        break;
      case 505:
        err.message = 'HTTP Version Not Supported(505)';
        break;
      default:
        err.message = `Connection error(${err.response.status})!`;
    }
  } else {
    err.message = 'Connection failure!';
  }
};

Axios.interceptors.request.use(config => {
  if (config.headers.isLoading !== false) {
    showLoading();
  }
  return config;
}, err => {
  handleErr(err);
  return Promise.reject(err);
});

Axios.interceptors.response.use(res => {
  if (res.config.headers.isLoading !== false) {
    hideLoading();
  }
  return res;
}, err => {
  handleErr(err);
  return Promise.reject(err);
});

Component.prototype.$axios = Axios;

export default Axios;
