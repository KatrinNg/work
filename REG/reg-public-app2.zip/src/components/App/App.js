import React from "react";
import {
  BrowserRouter as Router,
  Switch,
  Route
} from "react-router-dom";
import "../../assets/css/App.css";
import PublicEntryPage from "../../pages/main/PublicEntryPage";

function App() {
  return (
    <Router>
      <Switch>
        <Route path="/" component={PublicEntryPage} />
      </Switch>
    </Router>
  );
}

export default App;
