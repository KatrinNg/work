import React from "react";
import CssBaseline from "@material-ui/core/CssBaseline";

function HeaderPublic(props) {
    return (<>
        <div id="header">
            <CssBaseline />
        </div>
    </>);
}

export default HeaderPublic;
