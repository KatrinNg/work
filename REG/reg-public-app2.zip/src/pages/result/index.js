
import React, { useCallback, useEffect, useState } from "react";
import PropTypes from "prop-types";
import { makeStyles } from "@material-ui/core/styles";
import { Redirect, useHistory } from "react-router-dom";
import Grid from "@material-ui/core/Grid";
import haLogo from "../../assets/img/ha_logo.gif";
import thankPic from "../../assets/img/thanks.png";
import CloseIcon from '@material-ui/icons/Close';

const useStyles = makeStyles((theme) => ({
  wrapper: {
    padding: theme.spacing(3)
  },
  displayBox: {
    width: "80%",
    padding: theme.spacing(3),
    backgroundColor: "white",
    borderRadius: 32,
    boxShadow: "1px 1px 8px 0px"
  },
  closeButton: {
    marginRight:theme.spacing(1),
    cursor: "pointer",
    color:'#999999',
    "&:hover": {
      color: "#b3b3b3",
      borderRadius:'50px',
      border:'1px solid #f2f2f2',
      backgroundColor:'#f2f2f2',
      padding:'2px'
    }
  },
  img:{
      maxWidth:'90%'
  }
}));

const ResultPage = () => {
  const classes = useStyles();
  const history = useHistory();
  /* const { generatedQrCode_base64, form, email } = history?.location?.state || {
    generatedQrCode_base64: "",
    form: {},
    email: ""
  }; */

  // useEffect(() => {
  //   return () => {
  //     history.replace(''); //clear history state
  //   };
  // }, []);

  // if (src === src_prefix){
  //     return <Redirect to={"/"} />
  // }

  return (
    <div id="result">
      <div className="page-top-heading">
        <img className="ha-logo" src={haLogo} alt="logo" />
        <span
          className="page-title"
          style={{ display: "inline-block", margin: "15px 0" }}
        >
          Enquiry Portal for Non-
          <br />
          locally Trained Doctors
        </span>
      </div>
      <Grid container className={classes.wrapper} justifyContent={"center"}>
        <div className={classes.displayBox}>
          <Grid container justifyContent={"flex-end"}>
            <Grid item>
              <CloseIcon
                fontSize={"large"}
                className={classes.closeButton}
                onClick={()=>{history.replace("/");}}
              ></CloseIcon>
            </Grid>
          </Grid>
          <Grid container style={{margin:'100px 0px'}}>
          <Grid container item xs={6} alignContent={"center"} justifyContent={"center"}>
                <Grid item>
              <img alt={"thank you"} src={thankPic} style={{width:'80%'}}></img>
              </Grid>
            </Grid>
            <Grid container item xs={6} alignItems="center" alignContent="center" style={{padding:'0 20px'}}>
            <span className="resultText">
              {"Thank you for showing your interest. Our office will contact you in due course"}
            </span>
            </Grid>
          </Grid>
        </div>
      </Grid>
    </div>
  );
};
export default ResultPage;
