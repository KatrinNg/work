import React from "react";
import RegistrationInfoFormPublic from "../form/RegistrationInfoFormPublic";
import ResultPage from "../result";
import { Switch, Router, Route, Redirect } from "react-router-dom";

import LayoutPublic from "../../components/Layout/LayoutPublic";

const PublicEntryPage = ({history})=> {
    return (
        <Router history={history}>
            <LayoutPublic>
                <Switch>
                    <Route exact path="/public/inputRegistrationInfo" component={RegistrationInfoFormPublic} />
                    <Route exact path="/" component={RegistrationInfoFormPublic} />
                    <Route exact path="/public/result" component={ResultPage}/>
                    <Redirect from="*" to="/" />
                </Switch>
            </LayoutPublic>
        </Router>
    );
}

export default PublicEntryPage;
