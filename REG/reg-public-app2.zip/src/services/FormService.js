import { postUrl } from "./apiServices";

export const FormService = {
    postFormData
};

async function postFormData(data){
    const url = "registration";
    const opt = {
        responseType: '',
    };
    //data.creationTime = Date.now();
    const res = await postUrl(url,data, opt);
    return res
}

